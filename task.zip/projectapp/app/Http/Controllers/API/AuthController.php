<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\BlockIp;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:55',
            'email' => 'email|required|unique:users',
            'password' => 'required|confirmed'
        ]);

        $validatedData['password'] = Hash::make($request->password);

        $user = User::create($validatedData);

        $accessToken = $user->createToken('authToken')->accessToken;

        return response(['user' => $user, 'access_token' => $accessToken], 201);
    }

    public function login(Request $request)
    {
        $blackIPList = array();
        $loginData = $request->validate([
            'email' => 'email|required',
            'password' => 'required'
        ]);

        if (!auth()->attempt($loginData)) {
            $id = BlockIp::where("ip_address", $request->ip())->first();
            if($id){
                $current_date = Carbon::now();
                $formatedDate = $current_date->format('Y-m-d H:i:s');
                $block_info = BlockIp::find($id)->first();
                $start_date = $block_info->updated_at;
                $since_start = $start_date->diff($formatedDate);
                $minutes = $since_start->days * 24 * 60;
                $minutes += $since_start->h * 60;
                $minutes += $since_start->i;
                echo ($minutes);
                if ($minutes < 5) {
                    if ($block_info->count < 3) {
                        $block_info->count +=1;
                        $block_info->save();
                    }
                }else{
                    $block_info->updated_at = $current_date;
                    $block_info->save();
                }
            }else{
                $block_info = BlockIp::create(['ip_address'=>$request->ip(), 'count'=>'1']);
                // var_dump($block_info->id);
            }
            return response(['message' => 'This User does not exist, check your details'], 400);
        }

        $accessToken = auth()->user()->createToken('authToken')->accessToken;

        return response(['user' => auth()->user(), 'access_token' => $accessToken]);
    }
}
