<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use stdClass;
use App\Models\User;
use App\Models\BlockIp;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CheckIncorrectAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $id = Blockip::where('ip_address', $request->ip())->first();
        // var_dump($block_info);
        if ($id) {
            $block_info = Blockip::find($id)->first();
            if ($block_info->count >=3) {
                return response(['ip_address' => $request->ip(), 'state' => "Block"]);
                // return redirect()->route('login');
            }
        }
        return $next($request);
    }
}
